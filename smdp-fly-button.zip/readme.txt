=== Fly Button ===
Contributors: igomatos
Tags: button, sticky, fly, link
Donate link: https://cryptonews24.eu/index.php/donation-page/
Author: Ilias Gomatos
Author URI: https://soft-master.eu/
Requires at least: 5.0.1
Tested up to: 5.8
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later

Adds a fly button to a wordpress blog

== Description ==
A great way to monetize your blog by adding a fly button.

The plugin allows you to add a fly button to any WordPress theme. 

You can also adjust the button margin. 

You can choose the page that button been displayed.  

== Installation ==

Just follow the standard [WordPress plugin installation procedure](http://codex.wordpress.org/Managing_Plugins).

== Screenshots ==

See the [Documentation](https://soft-master.eu/smdp-fly-button-wordpress-plugin/) for more details.

1. SMDP Fly Button Main Settings.
2. SMDP Fly Button html Settings.

== Frequently asked questions ==

= The button is not showing=

Check button configuration for margins.


== Changelog ==

= 1.0.0 =
Initial Release
