jQuery( document ).ready( function ( e ) {
	
});